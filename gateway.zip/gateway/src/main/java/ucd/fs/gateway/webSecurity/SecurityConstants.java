package ucd.fs.gateway.webSecurity;

public class SecurityConstants {
    public static final String JWT_KEY = "maCleSecreteTrèsLonguePourJWTQueTuDoisChangerEtMettreEnSecurite123!";
    public static final String JWT_HEADER = "Authorization";
}
